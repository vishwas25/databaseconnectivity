using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Database_Connectivity_1
{
    public partial class Form1 : Form
    {
        private object dataGridView1;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionstring = "Data Source=Abhishek_Hajare\\SQLEXPRESS;Initial Catalog=sample_database;Integrated Security=True";

            string fname = textBox1.Text;
            string lname = textBox2.Text;
            string prn = textBox3.Text;
            string email = textBox4.Text;
            
            SqlConnection conn1 = new SqlConnection(connectionstring);
            string Query1 = "insert into info1 values ('" + fname + "','" + lname + "', '" + prn + "','" + email + "')";
            conn1.Open();
            SqlCommand cmd = new SqlCommand(Query1, conn1);
            cmd.ExecuteNonQuery();
            conn1.Close();
            MessageBox.Show("Data inserted sucessfully");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form f2 = new Form2();
            f2.Show();


        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}