﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Database_Connectivity_1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            string connectionstring = "Data Source=Abhishek_Hajare\\SQLEXPRESS;Initial Catalog=sample_database;Integrated Security=True";
            SqlConnection connect1 = new SqlConnection(connectionstring);
            string query1 = "Select * from info1";
            connect1.Open();
            SqlDataAdapter adapt = new SqlDataAdapter(query1, connect1);
            connect1.Close();

            DataTable dt = new DataTable();
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
